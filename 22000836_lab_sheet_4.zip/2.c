#include <stdio.h>
#include <stdlib.h>

int main(){
    
    int *numbers=NULL;
    int size=0;
    int input,i=0;
    
    printf("enter integers(-1 to stop):\n ");
    
    while(1){
        printf("enter an integer: ");
        scanf("%d",&input);
        
        if(input==-1){
            break;
        }
    
        
        numbers=(int*)realloc(numbers,(size+1)*sizeof(int));
        
        if(numbers==NULL){
            printf("memory allocation failiure\n");
            exit(EXIT_FAILURE);
        }
        numbers[size++]=input;
        
    }
    printf("reverse order of entered integers: \n");
    
    for(i=size-1;i>=0;--i){
        printf(" %d",numbers[i]);
        
    }
    free(numbers);
    return 0;
}