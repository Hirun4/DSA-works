#include <stdio.h>
#include <stdlib.h>

void *concatArrays(const void *arr1, int size1, const void *arr2, int size2, size_t elementSize) {
    if (arr1 == NULL || arr2 == NULL || size1 < 0 || size2 < 0 || elementSize == 0) {
        return NULL;
    }

    void *result = malloc((size1 + size2) * elementSize);

    if (result == NULL) {
        printf("Memory allocation error.\n");
        exit(EXIT_FAILURE);
    }

    char *resultPtr = (char *)result;

    
    for (int i = 0; i < size1; ++i) {
        const char *arr1Ptr = (const char *)arr1 + i * elementSize;
        for (size_t j = 0; j < elementSize; ++j) {
            *(resultPtr++) = *(arr1Ptr++);
        }
    }

   
    for (int i = 0; i < size2; ++i) {
        const char *arr2Ptr = (const char *)arr2 + i * elementSize;
        for (size_t j = 0; j < elementSize; ++j) {
            *(resultPtr++) = *(arr2Ptr++);
        }
    }

    return result;
}

int main() {
    int *arr1 = NULL, *arr2 = NULL, *concatenatedArr = NULL;
    int size1, size2;

    
    printf("Enter the number of elements for the first array: ");
    scanf("%d", &size1);

    
    arr1 = (int *)malloc(size1 * sizeof(int));

    if (arr1 == NULL) {
        printf("Memory allocation error.\n");
        exit(EXIT_FAILURE);
    }

    
    printf("Enter elements for the first array:\n");
    for (int i = 0; i < size1; ++i) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr1[i]);
    }

    
    printf("Enter the number of elements for the second array: ");
    scanf("%d", &size2);

    
    arr2 = (int *)malloc(size2 * sizeof(int));

    if (arr2 == NULL) {
        printf("Memory allocation error.\n");
        free(arr1);
        exit(EXIT_FAILURE);
    }

 
    printf("Enter elements for the second array:\n");
    for (int i = 0; i < size2; ++i) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr2[i]);
    }

    
    concatenatedArr = (int *)concatArrays(arr1, size1, arr2, size2, sizeof(int));

    if (concatenatedArr == NULL) {
        printf("Memory allocation error.\n");
        free(arr1);
        free(arr2);
        exit(EXIT_FAILURE);
    }

    
    printf("\nConcatenated array:\n");
    for (int i = 0; i < size1 + size2; ++i) {
        printf("%d ", concatenatedArr[i]);
    }
    printf("\n");

  
    free(arr1);
    free(arr2);
    free(concatenatedArr);

    return 0;
}


