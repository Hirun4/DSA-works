#include <stdio.h>

int main(){
    void *ptr;
    printf("size of void pointer:%zu ",sizeof(ptr));
    return 0;
}
