#include <stdio.h>
#include <stdlib.h>


void removeDuplicates(void *arr, int *size, size_t elementSize, int (*compare)(const void *, const void *)) {
    if (arr == NULL || size == NULL || elementSize == 0 || compare == NULL) {
        return;
    }

    char *arrayPtr = (char *)arr;

    
    for (int i = 0; i < *size; ++i) {
        char *currentElement = arrayPtr + i * elementSize;

        
        for (int j = i + 1; j < *size; ++j) {
            char *nextElement = arrayPtr + j * elementSize;

            if (compare(currentElement, nextElement) == 0) {
                
                for (int k = j; k < *size - 1; ++k) {
                    char *current = arrayPtr + k * elementSize;
                    char *next = arrayPtr + (k + 1) * elementSize;

                    for (size_t l = 0; l < elementSize; ++l) {
                        *(current++) = *(next++);
                    }
                }

                
                (*size)--;
                j--;  
            }
        }
    }
}


int compareInt(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

int main() {
    int *arr = NULL;
    int size;

    
    printf("Enter the number of integers to input: ");
    scanf("%d", &size);

    
    arr = (int *)malloc(size * sizeof(int));

    if (arr == NULL) {
        printf("Memory allocation error.\n");
        exit(EXIT_FAILURE);
    }

    
    printf("Enter %d integers: ", size);
    for (int i = 0; i < size; ++i) {
        scanf("%d", &arr[i]);
    }

    
    removeDuplicates(arr, &size, sizeof(int), compareInt);

    
    printf("Array after removing duplicates:");
    for (int i = 0; i < size; ++i) {
        printf(" %d", arr[i]);
    }
    printf("\n");

   
    free(arr);

    return 0;
}
