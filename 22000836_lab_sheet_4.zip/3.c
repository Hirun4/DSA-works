#include <stdio.h>
#include <stdlib.h>

void *findMaxElement(const void *arr, int size, size_t elementSize) {
    if (arr == NULL || size <= 0 || elementSize == 0) {
        return NULL;
    }

    const char *arrayPtr = (const char *)arr;
    void *maxElement = malloc(elementSize);

    if (maxElement == NULL) {
        printf("Memory allocation error.\n");
        exit(EXIT_FAILURE);
    }

   
    for (size_t i = 0; i < elementSize; ++i) {
        *((char *)maxElement + i) = *((char *)arrayPtr + i);
    }

    for (int i = 1; i < size; ++i) {
        arrayPtr += elementSize;

        
        for (size_t j = 0; j < elementSize; ++j) {
            char currentElement = *((char *)arrayPtr + j);
            char currentMax = *((char *)maxElement + j);

            if (currentElement > currentMax) {
                *((char *)maxElement + j) = currentElement;
            }
        }
    }

    return maxElement;
}

int main() {
    int *numbers = NULL;
    int size = 0;
    int capacity = 0;
    int input;

    while (1) {
        printf("Enter an integer (or -1 to stop): ");
        scanf("%d", &input);

        if (input == -1) {
            break;
        }

        if (size == capacity) {
            capacity = (capacity == 0) ? 1 : capacity * 2;
            numbers = (int *)realloc(numbers, capacity * sizeof(int));

            if (numbers == NULL) {
                printf("Memory allocation error.\n");
                exit(EXIT_FAILURE);
            }
        }

        numbers[size++] = input;
    }

    printf("\nEntered integers in reverse order:\n");
    for (int i = size - 1; i >= 0; --i) {
        printf("%d\n", numbers[i]);
    }

   
    void *maxElement = findMaxElement(numbers, size, sizeof(int));
    printf("\nMaximum element in the array: %d\n", *((int *)maxElement));

   
    free(numbers);
    free(maxElement);

    return 0;
}
