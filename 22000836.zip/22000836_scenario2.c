#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct Task {
    int id;
    char description[100];
    int completed;
    struct Task* next;
};


struct Task* addTask(struct Task* head, int id, const char* description) {
    struct Task* newTask = (struct Task*)malloc(sizeof(struct Task));
    if (newTask == NULL) {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }

    newTask->id = id;
    strcpy(newTask->description, description);
    newTask->completed = 0;
    newTask->next = head;

    return newTask;
}


void markCompleted(struct Task* head, int id) {
    struct Task* current = head;
    while (current != NULL) {
        if (current->id == id) {
            current->completed = 1;
            return;
        }
        current = current->next;
    }
    printf("Task not found\n");
}


struct Task* removeTask(struct Task* head, int id) {
    struct Task *current = head, *prev = NULL;

    while (current != NULL) {
        if (current->id == id) {
            if (prev != NULL) {
                prev->next = current->next;
            } else {
                head = current->next;
            }
            free(current);
            return head;
        }
        prev = current;
        current = current->next;
    }

    printf("Task not found\n");
    return head;
}


void displayTasks(struct Task* head) {
    printf("To-Do List:\n");
    struct Task* current = head;
    while (current != NULL) {
        printf("%d: %s [%s]\n", current->id, current->description,
               current->completed ? "Completed" : "Not Completed");
        current = current->next;
    }
}


void freeTasks(struct Task* head) {
    struct Task* current = head;
    while (current != NULL) {
        struct Task* next = current->next;
        free(current);
        current = next;
    }
}

int main() {
    struct Task* todoList = NULL;
    int choice, taskId;
    char taskDescription[100];

    do {
        printf("\nOptions:\n");
        printf("1. Add a new task\n");
        printf("2. Mark a task as completed\n");
        printf("3. Remove a task\n");
        printf("4. Display the to-do list\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter task description: ");
                scanf(" %[^\n]s", taskDescription);
                todoList = addTask(todoList, rand(), taskDescription);
                break;
            case 2:
                printf("Enter task ID to mark as completed: ");
                scanf("%d", &taskId);
                markCompleted(todoList, taskId);
                break;
            case 3:
                printf("Enter task ID to remove: ");
                scanf("%d", &taskId);
                todoList = removeTask(todoList, taskId);
                break;
            case 4:
                displayTasks(todoList);
                break;
            case 5:
                printf("Exiting the application\n");
                break;
            default:
                printf("Invalid choice\n");
        }
    } while (choice != 5);


    freeTasks(todoList);

    return 0;
}
