#include <stdio.h>
#include <stdlib.h>


struct Node 
{
    int dest;
    struct Node* next;
};


struct Graph 
{
    int V; 
    struct Node** array; 


struct Node* createNode(int dest)
{
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}


struct Graph* createGraph(int V) 
{
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;
    graph->array = (struct Node**)malloc(V * sizeof(struct Node*));

    
    for (int i = 0; i < V; ++i)
        graph->array[i] = NULL;

    return graph;
}


void addEdge(struct Graph* graph, int src, int dest) 
{
    
    struct Node* newNode = createNode(dest);
    newNode->next = graph->array[src];
    graph->array[src] = newNode;

    
    newNode = createNode(src);
    newNode->next = graph->array[dest];
    graph->array[dest] = newNode;
}


void printGraph(struct Graph* graph)
{
    for (int i = 0; i < graph->V; ++i) {
        printf("Adjacency list of vertex %d:\n", i);
        struct Node* temp = graph->array[i];
        while (temp) {
            printf(" -> %d", temp->dest);
            temp = temp->next;
        }
        printf("\n");
    }
}

int main()
{
    int V, E; 
    printf("Enter the number of vertices: ");
    scanf("%d", &V);
    printf("Enter the number of edges: ");
    scanf("%d", &E);

    struct Graph* graph = createGraph(V);

    printf("Enter the details of each edge (src dest):\n");
    for (int i = 0; i < E; ++i) {
        int src, dest;
        scanf("%d %d", &src, &dest);
        addEdge(graph, src, dest);
    }

    
    printGraph(graph);

    return 0;
}
