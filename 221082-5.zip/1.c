#include <stdio.h>
#include <stdlib.h>

struct node
{
    int dest;
    struct node* next;
};

struct graph
{
    int V;
    struct node** array;
};


struct node* createnode(int dest)
{
    struct node* newnode = (struct node*)malloc(sizeof(struct node));
    newnode->dest = dest;
    newnode->next = NULL;
    return newnode;
}


struct graph* creategraph(int V)
 {
    struct graph* graph = (struct graph*)malloc(sizeof(struct graph));
    graph->V = V;
    graph->array = (struct node**)malloc(V * sizeof(struct Node*));

    for (int i = 0; i < V; ++i)
        graph->array[i] = NULL;

    return graph;
}


void addEdge(struct graph* graph, int src, int dest)
 {
    struct node* newnode = createnode(dest);
    newnode->next = graph->array[src];
    graph->array[src] = newnode;
    newnode = createnode(src);
    newnode->next = graph->array[dest];
    graph->array[dest] = newnode;
}

void printgraph(struct graph* graph)
{
    for (int i = 0; i < graph->V; ++i)
        {
        printf("Adjacency list of vertex %d:\n", i);
        struct node* temp = graph->array[i];
        while (temp)
         {
            printf(" -> %d", temp->dest);
            temp = temp->next;
        }
        printf("\n");
    }
}

int main()
{
    int V, E;
    printf("Enter the number of vertices: ");
    scanf("%d", &V);
    printf("Enter the number of edges: ");
    scanf("%d", &E);

    struct graph* graph = creategraph(V);

    printf("Enter the details of each edge:\n");
    for (int i = 0; i < E; ++i)
        {
        int src, dest;
        scanf("%d %d", &src, &dest);
        addEdge(graph, src, dest);
       }

    printgraph(graph);

    return 0;
}
